package com.test.dao;

/**
 * 用户模块持久化层的接口：声明对USER_MESSAGE表进行操作的方法
 * @author 交大最帅的男人
 * @date 2024-5-6
 */
public interface UserMessageDao {
}
