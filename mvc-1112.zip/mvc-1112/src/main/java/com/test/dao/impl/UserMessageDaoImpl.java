package com.test.dao.impl;

import com.test.dao.UserMessageDao;

/**
 *
 * @author 交大最帅的男人
 */

public class UserMessageDaoImpl implements UserMessageDao {
}
