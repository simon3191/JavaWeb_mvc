package com.test.filter;

import javax.servlet.*;
import java.io.IOException;
/**
 * Created by 卢增强 2024/4/25.
 */
public class EncodingFilter implements Filter {
    //用于保存字符集的名称
    private String encoding = null;
    @Override
    public void init(FilterConfig config) throws ServletException {
        //过滤器初始化时，获取当前Filter在web.xml中，名字为encoding的私有信息的值
        this.encoding = config.getInitParameter("encoding");
    }

    @Override
    public void destroy() {
        this.encoding = null;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        request.setCharacterEncoding(this.encoding);
        response.setCharacterEncoding(this.encoding);
        response.setContentType("text/html;charset=" + this.encoding);
        //将请求与响应继续向下传递
        chain.doFilter(request, response);

    }

}
